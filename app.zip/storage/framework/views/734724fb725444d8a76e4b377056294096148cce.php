

<?php $__env->startSection('layout-content'); ?>
<!-- <script>
	window.onbeforeunload = function() {
	return "Take note of the Unique CodeData";
	};
</script> -->
 <?php if(!empty($Confrimed)): ?>
	<div class="modal fade" data-bs-backdrop="static" id="confirmed" tabindex="-1">
		<div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Successfully Applied</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body">
				<div class="alert alert-info" role="alert">
					<h4 class="alert-heading"><strong>Details Submitted Successfully</strong></h4>
					<hr>
					<p class="mb-0">Please take note of the <strong>Appointment Date</strong>, you can find it details on your email/Phone Number when confirmed</p>
				</div>
			</div>
			<div class="modal-footer">
				<a name="" id="" class="btn btn-sm btn-secondary me-auto" href="<?php echo e(route('welcome')); ?>" role="button"> 
					Close <i class="bi bi-check-circle"></i>
				</a>
			</div>
			</div>
		</div>
	</div>
<?php endif; ?>
<section class="mt-4">
	<div class="container">
		<div class="row">
			<div class="col-md-10 mx-auto">
				<!-- Page Title -->
				<h2>Registration Forms</h2>
				<!-- Page Description -->
				<div class="row">
					<div class="col-md-8">
						<h5 class="mt-5"><strong>Plesse Note:</strong></h5>
						<p>As you are registering, the system will provide you with a <strong>Unique Code</strong> that you will use to resume your registration process</p>
					</div>
					<?php if(!empty($token)): ?>
					<div class="col-md-4">
						<div class="alert alert-info" role="alert">
							<h4 class="alert-heading"><strong>Please Note!</strong></h4>
							<h2><strong><?php echo e($token); ?></strong></h2>
							<hr>
							<p class="mb-0">Please take note of the <strong>Unique Code</strong>, you will use it to resume application</p>
						</div>
					</div>
					<?php endif; ?>
				</div>
				<hr/>
				<?php if(!empty($message)): ?>
				<div class="alert alert-<?php echo e($status); ?> alert-dismissible fade show" role="alert">
					<strong><?php echo e($message); ?></strong>
					<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
				</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</section>
<section class="my-2 address">
	<div class="container mb-5">
		<div class="row">
			<div class="d-flex col-md-10 align-items-start mx-auto">
				<div class="nav flex-column nav-pills align-items-start mt-5" id="v-pills-tab" role="tablist" aria-orientation="vertical">
					<a style="width: 300px" href="<?php echo e(route('return_step1', ['token' => $token,'id' => $person_id])); ?>" class="nav-link my-2 text-start" id="v-pills-parta-tab" type="button" role="tab" aria-controls="v-pills-parta" aria-selected="true">
						PART A (Personal Information)
					</a>
					<a style="width: 300px" href="<?php echo e(route('return_step2', ['token' => $token,'id' => $person_id])); ?>" class="nav-link my-2 text-start" id="v-pills-parta_place-tab" type="button" role="tab" aria-controls="v-pills-parta_place" aria-selected="false">
						PART A (Place of Residence/birth/Origin)
					</a>
					<a style="width: 300px" class="nav-link my-2 text-start" id="v-pills-partb-tab" href="<?php echo e(route('third_form', ['token' => $token,'id' => $person_id])); ?>" type="button" role="tab" aria-controls="v-pills-partb" aria-selected="false">
						PART B (For Adults)
					</a>
					<a style="width: 300px" class="nav-link my-2 text-start" href="<?php echo e(route('fourth_form', ['token' => $token,'id' => $person_id])); ?>" id="v-pills-partcf-tab" type="button" role="tab" aria-controls="v-pills-partcf" aria-selected="false">
						PART C (Father's Details)
					</a>
					<a style="width: 300px" class="nav-link my-2 text-start" href="<?php echo e(route('fifth_form', ['token' => $token,'id' => $person_id])); ?>" id="v-pills-partcm-tab" type="button" role="tab" aria-controls="v-pills-partcm" aria-selected="false">
						PART C (Mother's Details)
					</a>
					<a style="width: 300px" class="nav-link my-2 text-start" href="<?php echo e(route('sixth_form', ['token' => $token,'id' => $person_id])); ?>" id="v-pills-partcg-tab" type="button" role="tab" aria-controls="v-pills-partcg" aria-selected="false">
						PART C (Guardian's Details)
					</a>
					<button style="width: 300px" class="nav-link my-2 text-start active" id="v-pills-confirm-tab" data-bs-toggle="pill" data-bs-target="#v-pills-confirm" type="button" role="tab" aria-controls="v-pills-confirm" aria-selected="false">
						CONFIRM INFORMATION
					</button>
				</div>
				<div class="tab-content" id="v-pills-tabContent">
					<div class="tab-pane fade show active" id="v-pills-confirm" role="tabpanel" aria-labelledby="v-pills-confirm-tab" tabindex="0">
						<div class="col-sm-10 m-auto text-center my-4">
							<h1>Confirm Your Information </h1>
						</div>
						<div class="col-10 mx-auto">
							<form method="POST" action="<?php echo e(route('confirm')); ?>">
								<?php echo csrf_field(); ?>
								<div class="row">
									<?php if(!empty($person_id)): ?>
									<input class="form-control main" type="hidden" name="personal_id" value="<?php echo e($person_id); ?>">
									<?php endif; ?>
									<div class="col-md-10 mb-2">
										<h3 class="text-weight-bold">PART A (Personal Details)</h3>
										<strong>Personal Information</strong>
									</div>
									<hr />
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Surname: </strong>
											<?php echo e($personal_info->surname); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Given Name: </strong>
											<?php echo e($personal_info->given_name); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Other Name: </strong>
											<?php echo e($personal_info->other_name); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Maiden Name: </strong>
											<?php echo e($personal_info->maiden_name); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Date of Birth: </strong>
											<?php echo e($personal_info->dob); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Email Address: </strong>
											<?php echo e($personal_info->email); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Home/Mobile No: </strong>
											<?php echo e($personal_info->mob_number); ?>

										</span>
									</div>

									<br/><br/>
									<div class="col-md-10 mb-2">
										<strong>Others</strong>
									</div>
									<hr />
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Highest Level of Education: </strong>
											<?php echo e($personal_info->education_level); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Occupation: </strong>
											<?php echo e($personal_info->occupation); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Religion: </strong>
											<?php echo e($personal_info->religion); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Disabilities: </strong>
											<?php echo e($personal_info->diabilities); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">LC1 Letter: </strong>
											<?php echo e($personal_info->lc_letter); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">DISO Letter: </strong>
											<?php echo e($personal_info->diso_letter); ?>

										</span>
									</div>


									<br/><br/><br/>
									<div class="col-md-10 mb-2">
										<h3 class="text-weight-bold">PART A (Residence Details)</h3>
										<strong>Place of Residence</strong>
									</div>
									<hr />
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Residence Type: </strong>
											<?php echo e($residence_info->type); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Country: </strong>
											<?php echo e($residence_info->country); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">District: </strong>
											<?php echo e($residence_info->ditrict); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">County: </strong>
											<?php echo e($residence_info->county); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Sub-County: </strong>
											<?php echo e($residence_info->sub_county); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Parish: </strong>
											<?php echo e($residence_info->parish); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Village: </strong>
											<?php echo e($residence_info->village); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Street: </strong>
											<?php echo e($residence_info->street); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">House Number: </strong>
											<?php echo e($residence_info->house_no); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Number of Years Lived: </strong>
											<?php echo e($residence_info->years_lived); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Previous Residence: </strong>
											<?php echo e($residence_info->previous_district); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Postal Address: </strong>
											<?php echo e($residence_info->previous_address); ?>

										</span>
									</div>


									<br/><br/>
									<div class="col-md-10 mb-2">
										<strong>Place of Birth</strong>
									</div>
									<hr />
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Country: </strong>
											<?php echo e($birth_info->country); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">District: </strong>
											<?php echo e($birth_info->ditrict); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">County: </strong>
											<?php echo e($birth_info->county); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Sub-County: </strong>
											<?php echo e($birth_info->sub_county); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Parish: </strong>
											<?php echo e($birth_info->parish); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Village: </strong>
											<?php echo e($birth_info->village); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">City: </strong>
											<?php echo e($birth_info->city); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Healthy Facility: </strong>
											<?php echo e($birth_info->health_facility); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Birth Weight: </strong>
											<?php echo e($birth_info->birth_weight); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Parity (Mother): </strong>
											<?php echo e($birth_info->parity); ?>

										</span>
									</div>


									<br/><br/>
									<div class="col-md-10 mb-2">
										<strong>Place of Origin</strong>
									</div>
									<hr />
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Country: </strong>
											<?php echo e($origin_info->country); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">District: </strong>
											<?php echo e($origin_info->ditrict); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">County: </strong>
											<?php echo e($origin_info->county); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Sub-County: </strong>
											<?php echo e($origin_info->sub_county); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Parish: </strong>
											<?php echo e($origin_info->parish); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Village: </strong>
											<?php echo e($origin_info->village); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Tribe: </strong>
											<?php echo e($origin_info->tribe); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Clan: </strong>
											<?php echo e($origin_info->clan); ?>

										</span>
									</div>


									<br/><br/>
									<div class="col-md-10 mb-2 ">
										<strong>Citzenship Details</strong>
									</div>
									<hr />
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Citzenship Type: </strong>
											<?php echo e($residence_info->citzenship); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">State Citzenship and Nationality (for Dual Citizenship): </strong>
											<?php echo e($residence_info->state_nationality); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Number of Years Lived at this Adress: </strong>
											<?php echo e($residence_info->citzenship_years); ?>

										</span>
									</div>















									<br/><br/><br/>
									<div class="col-md-10 mb-2">
										<h3 class="text-weight-bold">PART B (For Adults)</h3>
										<strong>Spause Details</strong>
									</div>
									<hr />
									<?php if(!empty($spouse_info)): ?>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Surname: </strong>
											<?php echo e($spouse_info->surname); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Given Name: </strong>
											<?php echo e($spouse_info->given_name); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Other Name: </strong>
											<?php echo e($spouse_info->other_name); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Maiden Name: </strong>
											<?php echo e($spouse_info->maiden_name); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">NIN: </strong>
											<?php echo e($spouse_info->nin); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Date of Marriage: </strong>
											<?php echo e($spouse_info->dom); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Place of Marriage: </strong>
											<?php echo e($spouse_info->marriage_place); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Marriage Type: </strong>
											<?php echo e($spouse_info->marriage_type); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Marriage Certificate No: </strong>
											<?php echo e($spouse_info->marriage_cert); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Citzenship: </strong>
											<?php echo e($spouse_info->citzenship); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">No. of Spouses: </strong>
											<?php echo e($spouse_info->spouse_number); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">State Citzenship and Country (If Dual Citzenship): </strong>
											<?php echo e($spouse_info->state_nationality); ?>

										</span>
									</div>
									<?php else: ?>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">No Spouse Details Found</strong>
										</span>
									</div>
									<?php endif; ?>
									











									<br/><br/><br/>
									<div class="col-md-10 mb-2">
										<h3 class="text-weight-bold">PART C (Father's Details)</h3>
										<strong>Details</strong>
									</div>
									<hr />
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Surname: </strong>
											<?php echo e($father_info->surname); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Given Name: </strong>
											<?php echo e($father_info->given_name); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Other Name: </strong>
											<?php echo e($father_info->other_name); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">NIN: </strong>
											<?php echo e($father_info->nin); ?>

										</span>
									</div>


									<br/><br/>
									<div class="col-md-10 mb-2 ">
										<strong>Citzenship Details</strong>
									</div>
									<hr />
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Citzenship Type: </strong>
											<?php echo e($father_info->citzenship); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">State Citzenship and Nationality (for Dual Citizenship): </strong>
											<?php echo e($father_info->state_nationality); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Number of Years Lived at this Adress: </strong>
											<?php echo e($father_info->citzenship_years); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Occupation: </strong>
											<?php echo e($father_info->occupation); ?>

										</span>
									</div>


									<br/><br/>
									<div class="col-md-10 mb-2 ">
										<strong>Father's Place of Residence</strong>
									</div>
									<hr />
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Country: </strong>
											<?php echo e($father_info->country); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">District: </strong>
											<?php echo e($father_info->ditrict); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">County: </strong>
											<?php echo e($father_info->county); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Sub-County: </strong>
											<?php echo e($father_info->sub_county); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Parish: </strong>
											<?php echo e($father_info->parish); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Village: </strong>
											<?php echo e($father_info->village); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Street: </strong>
											<?php echo e($father_info->street); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">House Number: </strong>
											<?php echo e($father_info->house_no); ?>

										</span>
									</div>



									<br/><br/>
									<div class="col-md-10 mb-2 ">
										<strong>Father's Place of Origin</strong>
									</div>
									<hr />
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Country: </strong>
											<?php echo e($father_info->ocountry); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">District: </strong>
											<?php echo e($father_info->oditrict); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">County: </strong>
											<?php echo e($father_info->ocounty); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Sub-County: </strong>
											<?php echo e($father_info->osub_county); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Parish: </strong>
											<?php echo e($father_info->oparish); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Village: </strong>
											<?php echo e($father_info->ovillage); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Street: </strong>
											<?php echo e($father_info->ostreet); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">House Number: </strong>
											<?php echo e($father_info->ohouse_no); ?>

										</span>
									</div>












									<br/><br/><br/>
									<div class="col-md-10 mb-2">
										<h3 class="text-weight-bold">PART C (Mother's Details)</h3>
										<strong>Details</strong>
									</div>
									<hr />
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Surname: </strong>
											<?php echo e($mother_info->surname); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Given Name: </strong>
											<?php echo e($mother_info->given_name); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Other Name: </strong>
											<?php echo e($mother_info->other_name); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Maiden Name: </strong>
											<?php echo e($mother_info->maiden_name); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">NIN: </strong>
											<?php echo e($mother_info->nin); ?>

										</span>
									</div>


									<br/><br/>
									<div class="col-md-10 mb-2 ">
										<strong>Citzenship Details</strong>
									</div>
									<hr />
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Citzenship Type: </strong>
											<?php echo e($mother_info->citzenship); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">State Citzenship and Nationality (for Dual Citizenship): </strong>
											<?php echo e($mother_info->state_nationality); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Number of Years Lived at this Adress: </strong>
											<?php echo e($mother_info->citzenship_years); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Occupation: </strong>
											<?php echo e($mother_info->occupation); ?>

										</span>
									</div>


									<br/><br/>
									<div class="col-md-10 mb-2 ">
										<strong>Mother's Place of Residence</strong>
									</div>
									<hr />
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Country: </strong>
											<?php echo e($mother_info->country); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">District: </strong>
											<?php echo e($mother_info->ditrict); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">County: </strong>
											<?php echo e($mother_info->county); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Sub-County: </strong>
											<?php echo e($mother_info->sub_county); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Parish: </strong>
											<?php echo e($mother_info->parish); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Village: </strong>
											<?php echo e($mother_info->village); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Street: </strong>
											<?php echo e($mother_info->street); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">House Number: </strong>
											<?php echo e($mother_info->house_no); ?>

										</span>
									</div>



									<br/><br/>
									<div class="col-md-10 mb-2 ">
										<strong>Mother's Place of Origin</strong>
									</div>
									<hr />
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Country: </strong>
											<?php echo e($mother_info->ocountry); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">District: </strong>
											<?php echo e($mother_info->oditrict); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">County: </strong>
											<?php echo e($mother_info->ocounty); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Sub-County: </strong>
											<?php echo e($mother_info->osub_county); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Parish: </strong>
											<?php echo e($mother_info->oparish); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Village: </strong>
											<?php echo e($mother_info->ovillage); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Street: </strong>
											<?php echo e($mother_info->ostreet); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">House Number: </strong>
											<?php echo e($mother_info->ohouse_no); ?>

										</span>
									</div>








									<br/><br/><br/>
									<div class="col-md-10 mb-2">
										<h3 class="text-weight-bold">PART C (Guardian's Details)</h3>
										<strong>Details</strong>
									</div>
									<hr />
									<?php if(!empty($guardian_info)): ?>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Surname: </strong>
											<?php echo e($guardian_info->surname); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Given Name: </strong>
											<?php echo e($guardian_info->given_name); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Other Name: </strong>
											<?php echo e($guardian_info->other_name); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Passport Number: </strong>
											<?php echo e($guardian_info->passport); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">NIN: </strong>
											<?php echo e($guardian_info->nin); ?>

										</span>
									</div>


									<br/><br/>
									<div class="col-md-10 mb-2 ">
										<strong>Citzenship Details</strong>
									</div>
									<hr />
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Citzenship Type: </strong>
											<?php echo e($guardian_info->citzenship); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">State Citzenship and Nationality (for Dual Citizenship): </strong>
											<?php echo e($guardian_info->state_nationality); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Occupation: </strong>
											<?php echo e($guardian_info->occupation); ?>

										</span>
									</div>


									<br/><br/>
									<div class="col-md-10 mb-2 ">
										<strong>Guardian's Place of Residence</strong>
									</div>
									<hr />
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Country: </strong>
											<?php echo e($guardian_info->country); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">District: </strong>
											<?php echo e($guardian_info->ditrict); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">County: </strong>
											<?php echo e($guardian_info->county); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Sub-County: </strong>
											<?php echo e($guardian_info->sub_county); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Parish: </strong>
											<?php echo e($guardian_info->parish); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Village: </strong>
											<?php echo e($guardian_info->village); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">Street: </strong>
											<?php echo e($guardian_info->street); ?>

										</span>
									</div>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">House Number: </strong>
											<?php echo e($guardian_info->house_no); ?>

										</span>
									</div>
									<?php else: ?>
									<div class="col-md-6 mb-2">
										<span>
											<strong class="form-label">No Spouse Details Found</strong>
										</span>
									</div>
									<?php endif; ?>








									




									<br/><br/><br/>
									<hr />
									<div class="col-md-10 mb-2">
										<h3 class="text-weight-bold">Declaration</h3>
										<strong>(Confirm by checking the checkbox)</strong>
									</div>
									<div class="form-check my-3">
										<input class="form-check-input" required name="declaration" type="checkbox" value="" id="declaration" style="width: 20px; height: 20px;">
										<p class="form-check-label ms-2" for="declaration">
											I <u class="mx-2"><strong><?php echo e($personal_info->surname); ?> <?php echo e($personal_info->given_name); ?></strong></u> declare that the information above pertaining to the birth of the child/applicant and particulars above is true and correct and that I know this of my own knowledge.
										</p>
									</div>
									<hr />
									<div class="col-md-12 d-flex mt-2">
										<button type="submit" class="btn btn-primary ms-auto">Submit Form <i class="ti-check"></i></button>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\online-booking\resources\views/forms/seventh_form.blade.php ENDPATH**/ ?>