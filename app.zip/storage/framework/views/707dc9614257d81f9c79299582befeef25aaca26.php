 

<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
      <h1>All Appointments</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
          <li class="breadcrumb-item active">Appoitments</li>
        </ol>
      </nav>
    </div>
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">All Appointments</h5>
                        <p>List of all appointments, please use the inputs to filter the list</p>
                        <!-- Table with stripped rows -->
                        <table class="table datatable">
                        <thead>
                            <tr>
                                <th scope="col">
                                    Name
                                </th>
                                <th scope="col">Location</th>
                                <th scope="col">Date of Birth</th>
                                <th scope="col">App'n Date</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                            <tbody>
                                <?php if(!empty($data)): ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php echo e($info_row->surname); ?> <?php echo e($info_row->given_name); ?>

                                        </td>
                                        <td>Kampala|Nakawa|Mutungo <?php echo e($info_row->residence->country); ?>| <?php echo e($info_row->residence->ditrict); ?>|<?php echo e($info_row->residence->county); ?></td>
                                        <td><?php echo e($info_row->dob); ?></td>
                                        <td><?php echo e($info_row->appointment_date); ?></td>
                                        <td>
                                            <a name="" id="" class="btn btn-outline btn-sm btn-primary" href="<?php echo e(route('applicant', ['id' => $info_row->id])); ?>" role="button">More...</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <tr>
                                    No Applications Found
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <!-- End Table with stripped rows -->

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\online-booking\resources\views/backend/appointments.blade.php ENDPATH**/ ?>