 

<?php $__env->startSection('content'); ?>
	<div class="modal fade" data-bs-backdrop="static" id="request-changes" tabindex="-1">
		<div class="modal-dialog  modal-lg">
			<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title"><strong>Changes Required</strong></h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body row d-flex px-5">
        <form method="POST" class="col-md-12 mx-auto" action="<?php echo e(route('request_changes')); ?>">
          <?php echo csrf_field(); ?>
          <div class="row col-md-12 my-2">
                <p>Just provide some information about what is required to be changed, this will help the applicant to respond appropriately</p>
                <div class="col-md-12 mb-4">
                  <input class="form-control main" type="hidden" name="id" value="<?php echo e($data->id); ?>">
                  <strong for="dob" class="form-label mb-2">Information about the changes <small class="text-danger">*</small></strong>
                  <textarea class="form-control main" required name="changes" cols="40" placeholder="Enter Request Information" rows="7"></textarea>
                </div>
            </div>
          </div>
          <div class="modal-footer px-5">
            <a name="" id="" class="btn btn-secondary" href="#" data-bs-dismiss="modal" aria-label="Close" role="button"> 
              Cancel <i class="ti-close"></i>
            </a>
            <button type="submit" class="btn btn-primary">Request  <i class="ti-check"></i></button>
          </div>
        </form>  
			</div>
		</div>
	</div>
  <div class="modal fade" data-bs-backdrop="static" id="complete-confirm" tabindex="-1">
		<div class="modal-dialog  modal-lg">
			<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title"><strong>Confirm Completion</strong></h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body row d-flex">
          <form method="POST" class="col-md-12 mx-auto" action="<?php echo e(route('finished_appointment')); ?>">
            <?php echo csrf_field(); ?>
              <div class="alert alert-info" role="alert">
                <h6 class="alert-heading"><strong>Do you want to complete Appointment?</strong></h6>
                <h6 class="mb-0">Please note this has been sent to the applicant's email/Phone SMS</h6>
              </div>
              <input class="form-control main" type="hidden" name="id" value="<?php echo e($data->id); ?>">
            <div class="modal-footer">
              <a name="" id="" class="btn btn-secondary" href="#" data-bs-dismiss="modal" aria-label="Close" role="button"> 
                Cancel <i class="ti-close"></i>
              </a>
              <button type="submit" class="btn btn-primary">Complete  <i class="ti-check"></i></button>
            </div>
          </form>  
        </div>
			</div>
		</div>
	</div>
    <div class="pagetitle">
      <h1 class="my-3"><?php echo e($data->surname); ?> <?php echo e($data->given_name); ?> Details</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
          <li class="breadcrumb-item"><a href="<?php echo e(route('appointments')); ?>">Applications</a></li>
          <li class="breadcrumb-item active">Applicant Details</li>
        </ol>
      </nav>
    </div>
    <section class="section profile">
      <div class="row">
        <div class="col-xl-12">
          <div class="card">
            <div class="card-title p-3 text-align-left">
              <?php if(!empty($data)): ?>
              <h5>Applications Status:
                 <?php if($data->step == 0): ?>
                <strong class="text-warning">Pending</strong>
                <?php elseif($data->step == 10): ?>
                <strong class="text-primary">Appointment Sent</strong>
                <?php else: ?>
                <strong class="text-success">Appointment Completed</strong>
                <?php endif; ?>
              </h5>
              <?php endif; ?>
                <div class="btn-group float-end" role="group" aria-label="Basic outlined example">
                  <?php if($data->step != 11): ?>
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#request-changes"><i class="bi bi-reply"></i> Request Changes</button>
                    <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#complete-confirm">Completed <i class="bi bi-check"></i></button>
                  <?php else: ?>
                  <button type="button" disabled class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#request-changes"><i class="bi bi-reply"></i> Request Changes</button>
                    <button type="button" disabled class="btn btn-success" data-bs-toggle="modal" data-bs-target="#complete-confirm">Completed <i class="bi bi-check"></i></button>
                  <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
              <ul class="nav nav-tabs nav-tabs-bordered d-flex" id="borderedTabJustified" role="tablist">
                <li class="nav-item flex-fill" role="presentation">
                  <button class="nav-link w-100 active" id="personal-info" data-bs-toggle="tab" data-bs-target="#bordered-justified-personal-info" type="button" role="tab" aria-controls="personal-info" aria-selected="true">Personal Information</button>
                </li>
                <li class="nav-item flex-fill" role="presentation">
                  <button class="nav-link w-100" id="residence" data-bs-toggle="tab" data-bs-target="#bordered-justified-residence" type="button" role="tab" aria-controls="residence" aria-selected="true">Place of Residence</button>
                </li>
                <li class="nav-item flex-fill" role="presentation">
                  <button class="nav-link w-100" id="spause" data-bs-toggle="tab" data-bs-target="#bordered-justified-spause" type="button" role="tab" aria-controls="spause" aria-selected="true">Spause</button>
                </li>
                <li class="nav-item flex-fill" role="presentation">
                  <button class="nav-link w-100" id="father" data-bs-toggle="tab" data-bs-target="#bordered-justified-father" type="button" role="tab" aria-controls="father" aria-selected="true">Father's Details</button>
                </li>
                <li class="nav-item flex-fill" role="presentation">
                  <button class="nav-link w-100" id="mother" data-bs-toggle="tab" data-bs-target="#bordered-justified-mother" type="button" role="tab" aria-controls="mother" aria-selected="true">Mother's Details</button>
                </li>
                <li class="nav-item flex-fill" role="presentation">
                  <button class="nav-link w-100" id="guardian" data-bs-toggle="tab" data-bs-target="#bordered-justified-guardian" type="button" role="tab" aria-controls="guardian" aria-selected="false">Guardian Details</button>
                </li>
                <li class="nav-item flex-fill" role="presentation">
                  <button class="nav-link w-100" id="officials" data-bs-toggle="tab" data-bs-target="#bordered-justified-officials" type="button" role="tab" aria-controls="officials" aria-selected="false">Documents</button>
                </li>
              </ul>
              <div class="tab-content pt-2" id="borderedTabJustifiedContent">
                <div class="tab-pane fade show active" id="bordered-justified-personal-info" role="tabpanel" aria-labelledby="personal-info">
                  <h5 class="card-title">Personal information</h5>
                  <p class="small fst-italic">Here you will find the personal Informationof the applicant</p>

                  <div class="row">
                    <div class="row col-md-6 my-2">
                      <strong>
                        <span class="text-muted me-3">Full Name:</span>  
                        <?php echo e($data->surname); ?> <?php echo e($data->given_name); ?> <?php echo e($data->other_name); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Maiden Name:</span>  <?php echo e($data->maiden_name); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Date of Birth:</span>  <?php echo e($data->dob); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Email:</span>  <?php echo e($data->email); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Mobile Number:</span>  <?php echo e($data->mob_number); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Highest Education:</span>  <?php echo e($data->education_level); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Occupation:</span>  <?php echo e($data->occupation); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Religion:</span>  <?php echo e($data->religion); ?></strong>  
                    </div>
                    <div class="row col-md-8 mt-4">
                      <strong>Place of Birth</strong>
                      <hr/>
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Country:</span>  <?php echo e($data->birthplace->country); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">District:</span>  <?php echo e($data->birthplace->ditrict); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Sub County:</span>  <?php echo e($data->birthplace->sub_county); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Parish:</span>  <?php echo e($data->birthplace->parish); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Village:</span>  <?php echo e($data->birthplace->village); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">City:</span>  <?php echo e($data->birthplace->city); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Health Facility:</span>  <?php echo e($data->birthplace->health_facility); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Weight on Birth:</span>  <?php echo e($data->birthplace->birth_weight); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Parity on Mother:</span>  <?php echo e($data->birthplace->parity); ?></strong>  
                    </div>
                  </div>
                </div>
                <div class="tab-pane fade" id="bordered-justified-residence" role="tabpanel" aria-labelledby="residence">
                  <h5 class="card-title">Residence</h5>
                  <p class="small fst-italic">Here you find the residence for the applicant</p>
                  <div class="row">
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Residence Type:</span>  <?php echo e($data->residence->type); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Country:</span>  <?php echo e($data->residence->country); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">District:</span>  <?php echo e($data->residence->ditrict); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Sub County:</span>  <?php echo e($data->residence->sub_county); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Parish:</span>  <?php echo e($data->residence->parish); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Village:</span>  <?php echo e($data->residence->village); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Street:</span>  <?php echo e($data->residence->street); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">House Number:</span>  <?php echo e($data->residence->house_no); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Year Lived in Address:</span>  <?php echo e($data->residence->years_lived); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Previous District:</span>  <?php echo e($data->residence->previous_district); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Previous Address:</span>  <?php echo e($data->residence->previous_address); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Citzenship:</span>  <?php echo e($data->residence->citzenship); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Years Lived in Adress:</span>  <?php echo e($data->residence->citzenship_years); ?></strong>  
                    </div>
                  </div>
                </div>
                <div class="tab-pane fade" id="bordered-justified-spause" role="tabpanel" aria-labelledby="spause">
                  <h5 class="card-title">Spause Details</h5>
                  <p class="small fst-italic">Here you find the Spouse details for the applicant</p>
                  <?php if(!empty($data->spouse)): ?>
                  <div class="row">
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Full Name:</span>  <?php echo e($data->spouse->surname); ?> <?php echo e($data->spouse->given_name); ?> <?php echo e($data->spouse->other_name); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Maiden Name:</span>  <?php echo e($data->spouse->maiden_name); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">NIN:</span>  <?php echo e($data->spouse->nin); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Date of Marriage:</span>  <?php echo e($data->spouse->dom); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Place of Marriage:</span>  <?php echo e($data->spouse->marriage_place); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Marriage Type:</span>  <?php echo e($data->spouse->marriage_type); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Marriage Certificate:</span>  <?php echo e($data->spouse->marriage_cert); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Citzenship:</span>  <?php echo e($data->spouse->citzenship); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">No of spouse:</span>  <?php echo e($data->spouse->spouce_number); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">State/Nationality:</span>  <?php echo e($data->spouse->state_nationality); ?></strong>  
                    </div>
                  </div>
                  <?php else: ?>
                  <div class="row">
                    <div class="row col-md-6 my-2">
                      <strong>No Spouse Details Put...</strong>  
                    </div>
                  </div>
                  <?php endif; ?>
                </div>
                <div class="tab-pane fade" id="bordered-justified-father" role="tabpanel" aria-labelledby="father">
                  <h5 class="card-title">Father's Details</h5>
                  <p class="small fst-italic">Here you find the Father's details for the applicant</p>
                  <div class="row">
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Full Name:</span>  <?php echo e($data->father->surname); ?> <?php echo e($data->father->given_name); ?> <?php echo e($data->father->other_name); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">NIN:</span>  <?php echo e($data->father->nin); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Citzenship:</span>  <?php echo e($data->father->citzenship); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Living State:</span>  <?php echo e($data->father->living_state); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Occupation:</span>  <?php echo e($data->father->occupation); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">State/Nationality:</span>  <?php echo e($data->father->state_nationality); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Country:</span>  <?php echo e($data->father->country); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">District:</span>  <?php echo e($data->father->ditrict); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Sub County:</span>  <?php echo e($data->father->sub_county); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Parish:</span>  <?php echo e($data->father->parish); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Village:</span>  <?php echo e($data->father->village); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Street:</span>  <?php echo e($data->father->street); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">House Number:</span>  <?php echo e($data->father->house_no); ?></strong>  
                    </div>
                    <div class="row col-md-8 mt-4">
                      <strong>Place of Origin</strong>
                      <hr/>
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Country:</span>  <?php echo e($data->father->ocountry); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">District:</span>  <?php echo e($data->father->oditrict); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Sub County:</span>  <?php echo e($data->father->osub_county); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Parish:</span>  <?php echo e($data->father->oparish); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Village:</span>  <?php echo e($data->father->ovillage); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Street:</span>  <?php echo e($data->father->ostreet); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">House Number:</span>  <?php echo e($data->father->ohouse_no); ?></strong>  
                    </div>
                  </div>
                </div>
                <div class="tab-pane fade" id="bordered-justified-mother" role="tabpanel" aria-labelledby="mother">
                  <h5 class="card-title">Mother's Details</h5>
                  <p class="small fst-italic">Here you find the Mother's details for the applicant</p>
                  <div class="row">
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Full Name:</span>  <?php echo e($data->mother->surname); ?> <?php echo e($data->mother->given_name); ?> <?php echo e($data->mother->other_name); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Maiden Name:</span>  <?php echo e($data->mother->maiden_name); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">NIN:</span>  <?php echo e($data->mother->nin); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Citzenship:</span>  <?php echo e($data->mother->citzenship); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Living State:</span>  <?php echo e($data->mother->living_state); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Occupation:</span>  <?php echo e($data->mother->occupation); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">State/Nationality:</span>  <?php echo e($data->mother->state_nationality); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Country:</span>  <?php echo e($data->mother->country); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">District:</span>  <?php echo e($data->mother->ditrict); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Sub County:</span>  <?php echo e($data->mother->sub_county); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Parish:</span>  <?php echo e($data->mother->parish); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Village:</span>  <?php echo e($data->mother->village); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Street:</span>  <?php echo e($data->mother->street); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">House Number:</span>  <?php echo e($data->mother->house_no); ?></strong>  
                    </div>
                    <div class="row col-md-8 mt-4">
                      <strong>Place of Origin</strong>
                      <hr/>
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Country:</span>  <?php echo e($data->mother->ocountry); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">District:</span>  <?php echo e($data->mother->oditrict); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Sub County:</span>  <?php echo e($data->mother->osub_county); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Parish:</span>  <?php echo e($data->mother->oparish); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Village:</span>  <?php echo e($data->mother->ovillage); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Street:</span>  <?php echo e($data->mother->ostreet); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">House Number:</span>  <?php echo e($data->mother->ohouse_no); ?></strong>  
                    </div>
                  </div>
                </div>
                <div class="tab-pane fade" id="bordered-justified-guardian" role="tabpanel" aria-labelledby="guardian">
                  <h5 class="card-title">Guardian's Details</h5>
                  <p class="small fst-italic">Here you find the Guardian details for the applicant</p>
                  <?php if(!empty($data->guardian)): ?>
                  <div class="row">
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Full Name:</span>  <?php echo e($data->guardian->surname); ?> <?php echo e($data->guardian->given_name); ?> <?php echo e($data->guardian->other_name); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Passport No:</span>  <?php echo e($data->guardian->passport); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">NIN:</span>  <?php echo e($data->guardian->nin); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Citzenship:</span>  <?php echo e($data->guardian->citzenship); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">State/Nationality:</span>  <?php echo e($data->guardian->state_nationality); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Country:</span>  <?php echo e($data->guardian->country); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">District:</span>  <?php echo e($data->guardian->ditrict); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Sub County:</span>  <?php echo e($data->guardian->sub_county); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Parish:</span>  <?php echo e($data->guardian->parish); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Village:</span>  <?php echo e($data->guardian->village); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">Street:</span>  <?php echo e($data->guardian->street); ?></strong>  
                    </div>
                    <div class="row col-md-6 my-2">
                      <strong><span class="text-muted me-3">House Number:</span>  <?php echo e($data->guardian->house_no); ?></strong>  
                    </div>
                    
                  </div>
                  <?php else: ?>
                  <div class="row">
                    <div class="row col-md-6 my-2">
                      <strong>No Guardian Details Put...</strong>  
                    </div>
                  </div>
                  <?php endif; ?>
                </div>
                <div class="tab-pane fade" id="bordered-justified-officials" role="tabpanel" aria-labelledby="officials">
                  <h5 class="card-title">Guardian's Details</h5>
                  <div class="row">
                    <div class="row col-md-8 my-2">
                      <strong>
                        <span class="text-muted me-3">LC1 Letter: </span> 
                        <a href="<?php echo e(url('/')); ?>/applicants/<?php echo e($data->lc_letter); ?>" target="_blank">Click to open document</a>
                      </strong>  
                    </div>
                    <div class="row col-md-8 my-2">
                      <strong>
                        <span class="text-muted me-3">DISO Letter: </span> 
                        <a href="<?php echo e(url('/')); ?>/applicants/<?php echo e($data->diso_letter); ?>" target="_blank">Click to open document</a>
                      </strong>  
                    </div>
                    <div class="row col-md-8 my-2">
                      <form method="POST" action="<?php echo e(route('appointment_date')); ?>">
                        <?php echo csrf_field(); ?>
                          <div class="col-md-10 mt-4">
                            <strong>Set Appointment</strong>
                          </div>
                          <hr />
                          <?php if($data->step == 0): ?>
                          <div class="col-md-8 mb-4">
                            <input class="form-control main" type="hidden" name="id" value="<?php echo e($data->id); ?>">
                            <label for="dob" class="form-label">Select Date <small class="text-danger">*</small></label>
                            <input class="form-control main" name="app_date" min="<?php echo date('Y-m-d') ?>" type="datetime-local" placeholder="Set Appointment Date" required>
                          </div>
                          <div class="col-md-8 d-flex mt-4">
                            <button type="submit" class="btn btn-primary ms-auto">Submit Appointment <i class="ti-check"></i></button>
                          </div>
                          <?php else: ?>
                          <div class="col-md-8 d-flex mt-4">
                            <strong class="text-primary">Appointment Already sent or Finished</strong>
                          </div>
                          <?php endif; ?>
                      </form>  
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <br/><br/><br/><br/>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\online-booking\resources\views/backend/application_details.blade.php ENDPATH**/ ?>