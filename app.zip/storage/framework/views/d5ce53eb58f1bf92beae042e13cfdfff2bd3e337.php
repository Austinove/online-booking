 

<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
      <h1>Faith Details</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
          <li class="breadcrumb-item"><a href="<?php echo e(route('appointments')); ?>">Applications</a></li>
          <li class="breadcrumb-item active">Applicant Details</li>
        </ol>
      </nav>
    </div>
    <section class="section profile">
      <div class="row">
        <div class="col-xl-12">
          <div class="card">
            <div class="card-title p-3 text-align-left">
                <div class="btn-group float-end" role="group" aria-label="Basic outlined example">
                    <button type="button" class="btn btn-sm btn-outline-danger"><i class="bi bi-x-circle"></i> Impersonation</button>
                    <button type="button" class="btn btn-sm btn-outline-info"><i class="bi bi-reply"></i> Request Changes</button>
                    <button type="button" class="btn btn-sm btn-sm btn-outline-success">Accept App <i class="bi bi-check-circle"></i></button>
                </div>
            </div>
            <div class="card-body">
              <!-- Bordered Tabs -->
              <ul class="nav nav-tabs nav-tabs-bordered">

                <li class="nav-item">
                  <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#personal-info">Personal Information</button>
                </li>
                <li class="nav-item">
                  <button class="nav-link" data-bs-toggle="tab" data-bs-target="#residence">Place of Residence</button>
                </li>
                <li class="nav-item">
                  <button class="nav-link" data-bs-toggle="tab" data-bs-target="#spause">Spause</button>
                </li>
                <li class="nav-item">
                  <button class="nav-link" data-bs-toggle="tab" data-bs-target="#father">Father's Details</button>
                </li>
                <li class="nav-item">
                  <button class="nav-link" data-bs-toggle="tab" data-bs-target="#mother">Mother's Details</button>
                </li>
                <li class="nav-item">
                  <button class="nav-link" data-bs-toggle="tab" data-bs-target="#guardian">Guardian's Details</button>
                </li>
                <li class="nav-item">
                  <button class="nav-link" data-bs-toggle="tab" data-bs-target="#official">Official Details</button>
                </li>
              </ul>
              <div class="tab-content">
                <div class="tab-pane fade show active personal-info" id="personal-info">
                  <h5 class="card-title">Personal Information</h5>
                  <div class="row">
                    <div class="col-md-11 mx-auto"><strong class="text-muted">Details</strong> <hr/></div>
                        <div class="col-md-11 mx-auto row">
                            <div class="col-md-4 label"><span><strong>Full Name:</strong> Applicant Name</span></div>
                            <div class="col-md-4 label"><span><strong>Email:</strong> Applicant Email</span></div>
                            <div class="col-md-4 label"><span><strong>Full Name:</strong> Applicant Name</span></div>
                            <div class="col-md-4 label"><span><strong>Email:</strong> Applicant Email</span></div>
                            <div class="col-md-4 label"><span><strong>Full Name:</strong> Applicant Name</span></div>
                            <div class="col-md-4 label"><span><strong>Email:</strong> Applicant Email</span></div>
                            <div class="col-md-4 label"><span><strong>Full Name:</strong> Applicant Name</span></div>
                            <div class="col-md-4 label"><span><strong>Email:</strong> Applicant Email</span></div>
                            <div class="col-md-4 label"><span><strong>Full Name:</strong> Applicant Name</span></div>
                            <div class="col-md-4 label"><span><strong>Email:</strong> Applicant Email</span></div>
                        </div>
                    </div>
                  </div>
                </div>
                
                <div class="tab-pane fade residence" id="residence">
                  <h5 class="card-title">Place of Residence</h5>
                </div>

                <div class="tab-pane fade spause" id="spause">
                  <h5 class="card-title">ssss</h5>
                </div>

                <div class="tab-pane fade" id="father">
                    <h5 class="card-title">Father Details</h5>
                  <div class="row">
                    <div class="col-md-11 mx-auto"><strong class="text-muted">Details</strong> <hr/></div>
                        <div class="col-md-11 mx-auto row">
                            <div class="col-md-4 label"><span><strong>Full Name:</strong> Applicant Name</span></div>
                            <div class="col-md-4 label"><span><strong>Email:</strong> Applicant Email</span></div>
                            <div class="col-md-4 label"><span><strong>Full Name:</strong> Applicant Name</span></div>
                            <div class="col-md-4 label"><span><strong>Email:</strong> Applicant Email</span></div>
                            <div class="col-md-4 label"><span><strong>Full Name:</strong> Applicant Name</span></div>
                            <div class="col-md-4 label"><span><strong>Email:</strong> Applicant Email</span></div>
                            <div class="col-md-4 label"><span><strong>Full Name:</strong> Applicant Name</span></div>
                            <div class="col-md-4 label"><span><strong>Email:</strong> Applicant Email</span></div>
                            <div class="col-md-4 label"><span><strong>Full Name:</strong> Applicant Name</span></div>
                            <div class="col-md-4 label"><span><strong>Email:</strong> Applicant Email</span></div>
                        </div>
                    </div>
                  </div>
                </div>

                <div class="tab-pane fade" id="mother">
                    <h5 class="card-title">Mother Details</h5>
                  <div class="row">
                    <div class="col-md-11 mx-auto"><strong class="text-muted">Details</strong> <hr/></div>
                        <div class="col-md-11 mx-auto row">
                            <div class="col-md-4 label"><span><strong>Full Name:</strong> Applicant Name</span></div>
                            <div class="col-md-4 label"><span><strong>Email:</strong> Applicant Email</span></div>
                            <div class="col-md-4 label"><span><strong>Full Name:</strong> Applicant Name</span></div>
                            <div class="col-md-4 label"><span><strong>Email:</strong> Applicant Email</span></div>
                            <div class="col-md-4 label"><span><strong>Full Name:</strong> Applicant Name</span></div>
                            <div class="col-md-4 label"><span><strong>Email:</strong> Applicant Email</span></div>
                            <div class="col-md-4 label"><span><strong>Full Name:</strong> Applicant Name</span></div>
                            <div class="col-md-4 label"><span><strong>Email:</strong> Applicant Email</span></div>
                            <div class="col-md-4 label"><span><strong>Full Name:</strong> Applicant Name</span></div>
                            <div class="col-md-4 label"><span><strong>Email:</strong> Applicant Email</span></div>
                        </div>
                    </div>
                  </div>
                </div>

                <div class="tab-pane fade" id="guadian">
                    <h5 class="card-title">Guardian Details</h5>
                  <div class="row">
                    <div class="col-md-11 mx-auto"><strong class="text-muted">Details</strong> <hr/></div>
                        <div class="col-md-11 mx-auto row">
                            <div class="col-md-4 label"><span><strong>Full Name:</strong> Applicant Name</span></div>
                            <div class="col-md-4 label"><span><strong>Email:</strong> Applicant Email</span></div>
                            <div class="col-md-4 label"><span><strong>Full Name:</strong> Applicant Name</span></div>
                            <div class="col-md-4 label"><span><strong>Email:</strong> Applicant Email</span></div>
                            <div class="col-md-4 label"><span><strong>Full Name:</strong> Applicant Name</span></div>
                            <div class="col-md-4 label"><span><strong>Email:</strong> Applicant Email</span></div>
                            <div class="col-md-4 label"><span><strong>Full Name:</strong> Applicant Name</span></div>
                            <div class="col-md-4 label"><span><strong>Email:</strong> Applicant Email</span></div>
                            <div class="col-md-4 label"><span><strong>Full Name:</strong> Applicant Name</span></div>
                            <div class="col-md-4 label"><span><strong>Email:</strong> Applicant Email</span></div>
                        </div>
                    </div>
                  </div>
                </div>

                <div class="tab-pane fade" id="official">
                    <h5 class="card-title">Official Only</h5>
                  <div class="row">
                    <div class="col-md-11 mx-auto"><strong class="text-muted">Details</strong> <hr/></div>
                        <div class="col-md-11 mx-auto row">
                            <div class="col-md-4 label"><span><strong>Full Name:</strong> Applicant Name</span></div>
                            <div class="col-md-4 label"><span><strong>Email:</strong> Applicant Email</span></div>
                            <div class="col-md-4 label"><span><strong>Full Name:</strong> Applicant Name</span></div>
                            <div class="col-md-4 label"><span><strong>Email:</strong> Applicant Email</span></div>
                            <div class="col-md-4 label"><span><strong>Full Name:</strong> Applicant Name</span></div>
                            <div class="col-md-4 label"><span><strong>Email:</strong> Applicant Email</span></div>
                            <div class="col-md-4 label"><span><strong>Full Name:</strong> Applicant Name</span></div>
                            <div class="col-md-4 label"><span><strong>Email:</strong> Applicant Email</span></div>
                            <div class="col-md-4 label"><span><strong>Full Name:</strong> Applicant Name</span></div>
                            <div class="col-md-4 label"><span><strong>Email:</strong> Applicant Email</span></div>
                        </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\online-booking\resources\views/backend/application_details.blade.php ENDPATH**/ ?>