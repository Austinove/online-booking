

<?php $__env->startSection('layout-content'); ?>
<!-- <section class="page-title my-5">
	<div class="container">
		<div class="row">
			<div class="col-sm-8 m-auto">
				<h1>Registration</h1>
			</div>
		</div>
	</div>
</section> -->

<section class="my-5 address">
	<div class="container d-flex">
		<div class="d-flex align-items-start mx-auto">
			<div class="nav flex-column nav-pills me-3 align-items-start mt-5" id="v-pills-tab" role="tablist" aria-orientation="vertical">
				<button class="nav-link active" id="v-pills-parta-tab" data-bs-toggle="pill" data-bs-target="#v-pills-parta" type="button" role="tab" aria-controls="v-pills-parta" aria-selected="true">FORM PART A</button>
				<button class="nav-link" id="v-pills-partb-tab" data-bs-toggle="pill" data-bs-target="#v-pills-partb" type="button" role="tab" aria-controls="v-pills-partb" aria-selected="false">FORM PART B</button>
				<button class="nav-link" id="v-pills-partcf-tab" data-bs-toggle="pill" data-bs-target="#v-pills-partcf" type="button" role="tab" aria-controls="v-pills-partcf" aria-selected="false" disabled>PART C (Father's Details) </button>
				<button class="nav-link" id="v-pills-partcm-tab" data-bs-toggle="pill" data-bs-target="#v-pills-partcm" type="button" role="tab" aria-controls="v-pills-partcm" aria-selected="false">PART C (Mother's Details)</button>
				<button class="nav-link" id="v-pills-partd-tab" data-bs-toggle="pill" data-bs-target="#v-pills-partd" type="button" role="tab" aria-controls="v-pills-partd" aria-selected="false">FORM PART D</button>
				<button class="nav-link" id="v-pills-confirm-tab" data-bs-toggle="pill" data-bs-target="#v-pills-confirm" type="button" role="tab" aria-controls="v-pills-confirm" aria-selected="false">CONFIRM INFORMATION</button>
			</div>
			<div class="tab-content" id="v-pills-tabContent">
				<div class="tab-pane fade show active row" id="v-pills-parta" role="tabpanel" aria-labelledby="v-pills-parta-tab" tabindex="0">
					<?php echo $__env->yieldContent('forms-a'); ?>
				</div>
				<div class="tab-pane fade" id="v-pills-partb" role="tabpanel" aria-labelledby="v-pills-partb-tab" tabindex="0">
					<div class="col-sm-10 m-auto text-center my-4">
						<h1>PART B</h1>
					</div>
					<div class="col-10 mx-auto">
						<form action="">
							<div class="row">
								<!-- Name -->
								<div class="col-md-6 mb-2">
									<input class="form-control main" type="text" placeholder="Name" required>
								</div>
								<!-- Email -->
								<div class="col-md-6 mb-2">
									<input class="form-control main" type="email" placeholder="Your Email Address" required>
								</div>
								<!-- subject -->
								<div class="col-md-12 mb-2">
									<input class="form-control main" type="text" placeholder="Subject" required>
								</div>
								<!-- Message -->
								<div class="col-md-12 mb-2">
									<textarea class="form-control main" name="message" rows="10" placeholder="Your Message"></textarea>
								</div>
								<!-- Submit Button -->
								<div class="col-12 text-right">
									<button class="btn btn-main-md">Submit</button>
								</div>
							</div>
						</form>
					</div>
				</div>
				<div class="tab-pane fade" id="v-pills-partcf" role="tabpanel" aria-labelledby="v-pills-partcf-tab" tabindex="0">
					<div class="col-sm-10 m-auto text-center my-4">
						<h1>PART C (Father's Details)</h1>
					</div>
				</div>
				<div class="tab-pane fade" id="v-pills-partcm" role="tabpanel" aria-labelledby="v-pills-partcm-tab" tabindex="0">
					<div class="col-sm-10 m-auto text-center my-4">
						<h1>PART C (Mother's Details) </h1>
					</div>
				</div>
				<div class="tab-pane fade" id="v-pills-partd" role="tabpanel" aria-labelledby="v-pills-partd-tab" tabindex="0">
					<div class="col-sm-10 m-auto text-center my-4">
						<h1>PART D </h1>
					</div>
				</div>
				<div class="tab-pane fade" id="v-pills-confirm" role="tabpanel" aria-labelledby="v-pills-confirm-tab" tabindex="0">...</div>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\online-booking\resources\views/forms/form.blade.php ENDPATH**/ ?>