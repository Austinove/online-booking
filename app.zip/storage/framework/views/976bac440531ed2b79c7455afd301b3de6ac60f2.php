

<?php $__env->startSection('content'); ?>
<div class="pagetitle">
    <h1>Scheduled Appointments</h1>
    <nav>
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item active">Scheduled Appointments</li>
    </ol>
    </nav>
</div>
<section class="section">
    <div class="row">
        <div class="col-12 row d-flex">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Appointment Schedules</h5>
                    <div id='caleandar'></div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\online-booking\resources\views/backend/new_appointments.blade.php ENDPATH**/ ?>